Toggle Switch
===============

Toggle Switch is a lightweight jQuery plugin which creates tiny and easy to use toggle buttons.

It is a visual element which can be a replacement for standard HTML checkboxes.
Simply run the script and your site will be updated with these specialized controls. Best of all, the underlying checkbox is not touched and backend system will never know the difference.

See the [project page] [Toggle Switch Site] for documentation and demonstration.

[Toggle Switch Site]: http://tinytools.codesells.com/toggleswitch